# ez-lunch TODO (Claudia)

Last updated: 2026-01-28

## Legend
- Priority: P0 (must), P1 (high), P2 (medium), P3 (low)
- Status: TODO | IN_PROGRESS | BLOCKED | DONE

## Tasks
| ID | Task | Priority | Estimate | Status | Notes |
|---:|------|:--------:|:--------:|:------:|------|
| 1 | Fix Git push auth reliability on this machine (non-interactive) | P0 | 0.5h | DONE | Configured credential helper to allow non-interactive pushes. |
| 2 | Make Preferences save/load DB-backed (API + Prisma upsert + UI wiring) | P0 | 3h | DONE | Server-backed /api/preferences + Prisma upsert + UI load/save; added prisma scripts + .env.example to make DB setup straightforward; UI keeps local fallback. |
| 3 | Add demo auth/user identity approach (demo user or simple login) | P1 | 2h | DONE | Added /login page + /api/login sets httpOnly cookie; API uses cookie (fallback demo) to upsert user for per-user prefs. |
| 4 | Add global Settings entry points consistency (header active state, links) | P2 | 0.5h | DONE | Already added /settings + nav + home entry point. |
| 5 | Add basic e2e smoke path (home → settings → preferences save) | P1 | 1.5h | DONE | Added scripts/smoke-preferences.sh manual smoke checklist. |
| 6 | UI polish: extract shared layout/header usage across all pages | P2 | 1h | DONE | Fixed SiteHeader imports; pages load again in dev. |
| 7 | Add CI (GitHub Actions): lint/typecheck + simple smoke tests (each page loads) | P3 | 2h | DONE | Added .github/workflows/ci.yml running npm ci + lint + typecheck + next build. Fixed /preferences build crash by guarding localStorage access in save.ts. |
| 8 | Add README “run locally” + env setup | P3 | 0.5h | DONE | Updated README with local setup steps (.env, prisma migrate, dev server) + added typecheck script and ignored tsbuildinfo. |
| 9 | Align app with golden-standard deck flow: Subscribe → Preferences → Confirm next-day meal → Delivery status | P2 | 4h | DONE | Added /confirm + /delivery pages, header nav entries, and CTAs to move through the flow. |
| 10 | Add “Confirm tomorrow’s meal” UX (choose/override suggestion) | P2 | 3h | DONE | Added /api/tomorrow (GET suggestion/options + POST confirm). Confirm page loads from API and posts choice; Delivery page reads API to show confirmed meal. Writes MealPlanItem + MealEvent. |
| 11 | Add basic meal plan generation (stub AI): generate weekly lineup from menu + preferences | P2 | 3h | DONE | Added shared MENU + deterministic weekly plan generator (diet-aware) and /api/tomorrow now ensures week plan/items exist (creates missing items, doesn't overwrite). |
| 12 | Align homepage copy + flow with golden standard PDF (Problem/Solution, $300/mo, steps) | P2 | 1.5h | DONE | Updated homepage sections to match PDF language and flow. |
| 13 | Expand menu with real Bay Area restaurant meals (target 2000 items) | P1 | 8h | IN_PROGRESS | Continuing to append meals (+10 per tick).
| 14 | Fix any broken “Confirm tomorrow” links + add compatibility route(s) | P1 | 0.5h | DONE | Added /confirm-tomorrow redirect + ensured /confirm route exists.
| 15 | Add Map page showing restaurants + delivery areas | P2 | 3h | IN_PROGRESS | Map page now shows pins; expanded geocode list for new restaurants.
| 16 | Map: upgrade delivery areas from circles to simple zones (convex hull / cluster) | P2 | 4h | IN_PROGRESS | Added convex hull overlays + basic unit tests.


## Next up (execution order)
1) Task 1 (push auth reliability)
2) Task 2 (DB-backed preferences)
3) Task 5 (smoke path)
