#!/usr/bin/env python3
"""Append N new companies from companies_seed.txt into companies.csv.

Usage:
  python3 scripts/append_companies.py 5

Notes:
- Dedupes against existing companies.csv
- Skips comment lines in companies_seed.txt
"""

import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SEED = ROOT / "companies_seed.txt"
OUT = ROOT / "companies.csv"

N = int(sys.argv[1]) if len(sys.argv) > 1 else 5

if not SEED.exists():
    raise SystemExit(f"missing {SEED}")

seed = []
for line in SEED.read_text().splitlines():
    line = line.strip()
    if not line or line.startswith("#"):
        continue
    seed.append(line)

existing = set()
rows = []
if OUT.exists():
    with OUT.open(newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            c = (row.get("company") or "").strip()
            if c:
                existing.add(c)
            rows.append(row)

added = 0
for c in seed:
    if c in existing:
        continue
    rows.append({"company": c, "first_seen_job_url": "", "status": "PLANNED", "notes": ""})
    existing.add(c)
    added += 1
    if added >= N:
        break

OUT.parent.mkdir(parents=True, exist_ok=True)
with OUT.open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["company", "first_seen_job_url", "status", "notes"])
    w.writeheader()
    for row in rows:
        w.writerow({
            "company": (row.get("company") or "").strip(),
            "first_seen_job_url": (row.get("first_seen_job_url") or "").strip(),
            "status": (row.get("status") or "").strip(),
            "notes": (row.get("notes") or "").strip(),
        })

print(f"added {added} companies; total now {len(rows)}")
