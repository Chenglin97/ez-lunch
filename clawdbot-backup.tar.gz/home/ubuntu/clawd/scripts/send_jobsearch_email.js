const fs = require('fs');
const nodemailer = require('nodemailer');

const secretPath = process.env.SECRET_PATH || '/home/ubuntu/chenglin/secret.txt';
const from = process.env.EMAIL_FROM || 'chenglinwai01@gmail.com';
const to = process.env.EMAIL_TO || 'chenglinwei97@gmail.com';

function getGmailAppPassword() {
  const lines = fs.readFileSync(secretPath, 'utf8')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean);
  // Convention: second non-empty line is the Gmail app password
  const pass = lines[1];
  if (!pass) throw new Error(`Missing Gmail app password in ${secretPath} (expected on 2nd non-empty line).`);
  return pass;
}

async function main() {
  const pass = getGmailAppPassword();

  const attachments = [
    { filename: 'applications.csv', path: '/home/ubuntu/clawd/applications.csv' },
    { filename: 'companies.csv', path: '/home/ubuntu/clawd/companies.csv' },
    { filename: 'networking.md', path: '/home/ubuntu/clawd/networking.md' },
  ];

  const text = `Job search tracker files (auto-sent)\n\nAttached:\n- applications.csv (positions)\n- companies.csv (company queue)\n- networking.md (planned outreach)\n\nIf you want a clean Excel import: I can normalize applications.csv quoting (or switch to a fresh applications_clean.csv).\n`;

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: from, pass },
  });

  const info = await transporter.sendMail({
    from,
    to,
    subject: 'Job search tracker files (auto)',
    text,
    attachments,
  });

  console.log('Email sent:', info.messageId);
}

main().catch((e) => {
  console.error('Failed to send email:', e.message);
  process.exit(1);
});
