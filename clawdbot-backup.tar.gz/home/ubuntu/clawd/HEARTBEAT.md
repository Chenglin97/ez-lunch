# HEARTBEAT.md

# Enable heartbeats so cron wake events can reliably trigger agent turns.
# (This keeps the heartbeat system active.)

- keepalive: allow cron wake events to execute
