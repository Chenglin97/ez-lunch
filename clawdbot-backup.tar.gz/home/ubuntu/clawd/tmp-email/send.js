const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');

const secretPath = '/home/ubuntu/chenglin/secret.txt';
const secret = fs.readFileSync(secretPath, 'utf8').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
// Expect: [github_pat..., gmail_app_password]
const gmailAppPassword = secret[1];
if (!gmailAppPassword) {
  throw new Error('No Gmail app password found in secret.txt (expected on second non-empty line).');
}

const from = 'chenglinwai01@gmail.com';
const to = 'chenglinwei97@gmail.com';

const attachments = [
  { filename: 'applications.csv', path: '/home/ubuntu/chenglin/jobsearch/applications.csv' },
  { filename: 'targets.md', path: '/home/ubuntu/chenglin/jobsearch/targets.md' },
  { filename: 'networking.md', path: '/home/ubuntu/chenglin/jobsearch/networking.md' },
];

const text = `Job search TODO + tracker files\n\nAttached:\n- applications.csv (applications tracker)\n- targets.md (target roles/constraints)\n- networking.md (outreach templates + log)\n\nNext steps:\n1) Apply to OpenAI / Anthropic / Waymo / Stripe / Nuro (links are in applications.csv)\n2) After each application: message 1 recruiter + 1 engineer on LinkedIn (template in networking.md)\n3) Tell me which ones you submitted; I will mark SUBMITTED + set follow-up dates.\n`;

async function main() {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: from,
      pass: gmailAppPassword,
    },
  });

  const info = await transporter.sendMail({
    from,
    to,
    subject: 'Job search TODO + trackers',
    text,
    attachments,
  });

  // Log minimal info (no secrets)
  console.log('Email sent:', info.messageId);
}

main().catch((e) => {
  console.error('Failed to send email:', e.message);
  process.exit(1);
});
